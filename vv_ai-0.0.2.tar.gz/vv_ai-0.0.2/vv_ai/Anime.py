from openai import OpenAI
client = OpenAI()
import webbrowser 

promptname = ""
def getanime(promptname):
 response = client.images.generate(
  model="dall-e-3",
  prompt=promptname,
  size="1024x1024",
  quality="standard",
  n=1,
)
 return response.data[0].url

image_url = getanime(promptname)
#image_url = getanime(r"an animated sad girl")
webbrowser.open(image_url) 
#print(image_url)