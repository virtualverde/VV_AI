import openai
import os
import urllib
from IPython.display import Audio
from pathlib import Path
from pydub import AudioSegment



from tkinter import *
  

#top = Tk() 

#scrollbar = Scrollbar(top)
#scrollbar.pack(side=RIGHT, fill=Y)
#e1 = Entry(top) 
#e1.grid(row=0,column=1) 
#Button(top, text='upload').grid(row=0) 


#Lb = Listbox(top, wrap=WORD) 
#vvfile = 'C:\Users\Ashu\OneDrive\Songs\Vakratunda Maharaja Ganapati - Copy.m4a'
#vvdrive = 'D:'

def transcribe_audio(vvfile,vvdrive):
    audio_path = os.path.join(vvdrive, vvfile)
    with open(audio_path, 'rb') as audio_data:
        transcription = openai.Audio.transcribe("whisper-1", audio_data)
        if(vvfile) & (vvdrive):
             return transcription['text']
        else:
            return transcription['file name and path is empty']

#ourMessage = transcribe_audio(vvfile,vvdrive)
#ourMessage = transcribe_audio(r"C:\Users\Ashu\OneDrive\Songs\Vakratunda Maharaja Ganapati - Copy.m4a","D:")

#print(ourMessage)
#Lb.insert(END, ourMessage)
#Lb.pack(expand=1,fill=BOTH) 
#Lb.config(yscrollcommand=scrollbar.set)
#scrollbar.config(command=Lb.yview)

#top.mainloop() 

