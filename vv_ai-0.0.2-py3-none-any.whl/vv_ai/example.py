import City



mymessage = City.roam_city("Seattle")
print(mymessage)