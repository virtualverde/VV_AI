
import openai
import os
import urllib
from IPython.display import Audio
from pathlib import Path
from pydub import AudioSegment

import webbrowser 

from tkinter import *
  

top = Tk() 


e1 = Entry(top) 
e1.grid(row=0,column=1) 


Lb = Listbox(top) 

from openai import OpenAI
client = OpenAI()

cityname = ""
def roam_city(cityname):
    response = client.images.generate(
    model="dall-e-3",
    prompt=cityname,
    n=1,
    size="1024x1024",
    )
    
    if (cityname) :       
        return  response.data[0].url
    else:
        return 'city name is empty'


ourMessage = roam_city(cityname)
#ourMessage = roam_city(r"Newyork")
T = Text(top, height = 1024, width = 1024) 
top.title("WebBrowsers") 
webbrowser.open(ourMessage) 


#top.mainloop() 

