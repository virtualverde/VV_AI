from openai import OpenAI
client = OpenAI()

systemval = ""
userval =  ""
def getEmail(systemval,userval):
  response = client.chat.completions.create(
  model="gpt-3.5-turbo",
  messages=[
    #{"role": "system", "content": "You are a helpful assistant."},
    #{"role": "user", "content": "Can you write a mail on how to sell a product?"},
    {"role": "system", "content": systemval},
    {"role": "user", "content": userval},
  ]
)
  return response.choices[0].message.content

#print(response.choices[0].message.content)